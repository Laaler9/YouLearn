import SwiftUI

struct Learn: View {
    var body: some View {
        Text("Learn Page")
            .navigationTitle("working on it, coming soon...")
    }
}

struct Learn_Previews: PreviewProvider {
    static var previews: some View {
        Learn()
    }
}

