import SwiftUI

struct Credits: View {
    var body: some View {
        Text("Credits Page")
            .navigationTitle("made by laaler9 on github.")
    }
}

struct Credits_Previews: PreviewProvider {
    static var previews: some View {
        Credits()
    }
}

